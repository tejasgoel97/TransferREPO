const initialState = {}


const CartReducer = (state=initialState, action) =>{

    return state
}


export default CartReducer