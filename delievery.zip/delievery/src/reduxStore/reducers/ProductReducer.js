const initialState = {}


const ProductReducer = (state=initialState, action) =>{

    return state
}


export default ProductReducer;