//Colors for the BottomTabNavigator
export const themeColor= "#519259"

export const textColor =  "rgb(77, 77, 77)"
export const priceTextColor = "#ff6b6b"

export const TabActiveColor = themeColor
export const TabInActiveColor = 'grey'
export const AddToCartColor = themeColor